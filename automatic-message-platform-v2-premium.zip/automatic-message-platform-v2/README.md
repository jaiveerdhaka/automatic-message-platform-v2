# Automatic Message Platform V2

Premium WhatsApp automation SaaS starter with a real PostgreSQL data model, Express API, Redis/BullMQ scheduler/worker, Next.js admin panel, CSV/XLSX contact import, template builder, campaign scheduling, automation rules, analytics, and WhatsApp Cloud API webhook status tracking.

## Run
1. Copy `.env.example` to `.env` and add your WhatsApp Cloud API values.
2. Run `docker compose up --build`.
3. Open `http://localhost:3000` for the admin panel and `http://localhost:4000/health` for API health.
4. Seed admin: `admin@example.com` / `admin123` (change this before production).

## WhatsApp setup
Point Meta's webhook callback to `/api/webhooks/whatsapp`, use the configured verify token, and subscribe to message status events. For production, put the API behind HTTPS and set `WHATSAPP_APP_SECRET` so signature validation is enabled.

## CSV/XLSX
Import columns named `phone`, `name`, and `email` (case variants are accepted). Phone values should be normalized to WhatsApp-compatible international format.

## Production checklist
- Replace password hashing with Argon2/bcrypt and rotate the JWT secret.
- Add rate limiting, audit logs, RBAC enforcement per route, CSRF protections where applicable, backups, monitoring and HTTPS.
- Store Meta-approved template names/languages exactly as configured in WhatsApp Manager.
- Implement opt-in/opt-out enforcement and quiet-hour rules before sending marketing traffic.
- Add pagination/search indexes and object storage for media.
