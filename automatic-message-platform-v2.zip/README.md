# Automatic Message Platform V2

Production-oriented starter for legitimate, opt-in WhatsApp customer messaging.

## Stack
- API: Node.js 20 + Express
- DB: PostgreSQL 16
- Queue: Redis + BullMQ
- Dashboard: Next.js 15
- WhatsApp: Meta WhatsApp Cloud API
- Deployment: Docker Compose

## Quick start

```bash
cp .env.example .env
docker compose up --build
```

Open:
- Dashboard: http://localhost:3000
- API: http://localhost:4000
- Health: http://localhost:4000/health
- Swagger/OpenAPI JSON: http://localhost:4000/openapi.json

The database schema is applied automatically from `api/migrations/001_init.sql`.

## First API key
Set `INITIAL_API_KEY` in `.env`. The server stores only its SHA-256 hash.

## WhatsApp setup
Set:
- `WHATSAPP_ACCESS_TOKEN`
- `WHATSAPP_PHONE_NUMBER_ID`
- `WHATSAPP_GRAPH_VERSION`
- `WHATSAPP_VERIFY_TOKEN`
- `WHATSAPP_APP_SECRET` (recommended)

Configure Meta's webhook callback URL as:
`https://YOUR-DOMAIN/webhooks/whatsapp`
and subscribe to the WhatsApp message events. The GET endpoint handles verification; the POST endpoint validates the signature when `WHATSAPP_APP_SECRET` is configured and records incoming webhook events.

## Send a template message

```bash
curl -X POST http://localhost:4000/api/v1/messages/send \
  -H "Content-Type: application/json" \
  -H "X-API-Key: change-this-to-a-long-random-key" \
  -d '{
    "to":"+230XXXXXXXX",
    "template":"welcome",
    "language":"en_US",
    "variables":{"name":"Customer"}
  }'
```

## Important
Use only for recipients who have provided the appropriate consent/opt-in and use approved WhatsApp templates where required. This project does not implement spam, scraping, credential theft, or platform-policy bypassing.
