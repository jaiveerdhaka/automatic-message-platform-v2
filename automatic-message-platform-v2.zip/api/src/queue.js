import IORedis from 'ioredis';
import { Queue } from 'bullmq';
export const connection = new IORedis(process.env.REDIS_URL, { maxRetriesPerRequest: null });
export const messageQueue = new Queue('messages', { connection });
