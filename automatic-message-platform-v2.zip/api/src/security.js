import crypto from 'crypto';
export const sha256 = value => crypto.createHash('sha256').update(value).digest('hex');
export function safeEqualHex(a,b) {
  try {
    const x=Buffer.from(a,'hex'), y=Buffer.from(b,'hex');
    return x.length===y.length && crypto.timingSafeEqual(x,y);
  } catch { return false; }
}
export function verifyMetaSignature(rawBody, signature, appSecret) {
  if (!appSecret || !signature?.startsWith('sha256=')) return false;
  const expected='sha256='+crypto.createHmac('sha256',appSecret).update(rawBody).digest('hex');
  return safeEqualHex(expected.slice(7), signature.slice(7));
}
