import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import crypto from 'crypto';
import { z } from 'zod';
import { query } from './db.js';
import { messageQueue } from './queue.js';
import { sha256, verifyMetaSignature } from './security.js';

const app=express();
app.use(cors({origin:process.env.CORS_ORIGIN ? process.env.CORS_ORIGIN.split(',') : true}));
app.use('/webhooks/whatsapp',express.raw({type:'application/json',limit:'1mb'}));
app.use(express.json({limit:'100kb'}));

async function auth(req,res,next){
  const key=req.header('X-API-Key');
  if(!key) return res.status(401).json({error:'Missing API key'});
  const r=await query('SELECT id FROM api_keys WHERE key_hash=$1 AND active=true',[sha256(key)]);
  if(!r.rowCount) return res.status(401).json({error:'Invalid API key'});
  await query('UPDATE api_keys SET last_used_at=now() WHERE id=$1',[r.rows[0].id]);
  next();
}
const sendSchema=z.object({
  to:z.string().min(7).max(30),
  channel:z.literal('whatsapp').default('whatsapp'),
  template:z.string().regex(/^[a-z0-9_]+$/).max(100),
  language:z.string().regex(/^[a-z]{2}_[A-Z]{2}$/).default('en_US'),
  variables:z.record(z.string(),z.union([z.string(),z.number(),z.boolean()])).default({})
});

app.get('/health',(_,res)=>res.json({ok:true,service:'automatic-message-api',time:new Date().toISOString()}));

app.get('/openapi.json',(_,res)=>res.json({
  openapi:'3.0.3',info:{title:'Automatic Message API',version:'2.0.0'},
  paths:{
    '/api/v1/messages/send':{post:{security:[{ApiKey:[]}],summary:'Queue a WhatsApp template message'}},
    '/api/v1/messages':{get:{security:[{ApiKey:[]}],summary:'List message logs'}},
    '/api/v1/contacts':{post:{security:[{ApiKey:[]}],summary:'Create/update opt-in contact'}},
    '/webhooks/whatsapp':{get:{summary:'Meta verification'},post:{summary:'WhatsApp webhook'}}
  },
  components:{securitySchemes:{ApiKey:{type:'apiKey',in:'header',name:'X-API-Key'}}}
}));

app.post('/api/v1/contacts',auth,async(req,res)=>{
  const p=z.object({phone:z.string().min(7).max(30),name:z.string().max(200).optional(),opted_in:z.boolean(),metadata:z.record(z.string(),z.any()).default({})}).safeParse(req.body);
  if(!p.success) return res.status(400).json({error:'Invalid contact',details:p.error.flatten()});
  const {phone,name,opted_in,metadata}=p.data;
  const r=await query(`INSERT INTO contacts(phone,name,opted_in,opted_in_at,metadata)
    VALUES($1,$2,$3,CASE WHEN $3 THEN now() ELSE NULL END,$4)
    ON CONFLICT(phone) DO UPDATE SET name=EXCLUDED.name,opted_in=EXCLUDED.opted_in,
    opted_in_at=CASE WHEN EXCLUDED.opted_in THEN COALESCE(contacts.opted_in_at,now()) ELSE contacts.opted_in_at END,
    opted_out_at=CASE WHEN NOT EXCLUDED.opted_in THEN now() ELSE NULL END,
    metadata=EXCLUDED.metadata,updated_at=now() RETURNING *`,
    [phone,name||null,opted_in,JSON.stringify(metadata)]);
  res.status(201).json({contact:r.rows[0]});
});

app.post('/api/v1/messages/send',auth,async(req,res)=>{
  const p=sendSchema.safeParse(req.body);
  if(!p.success) return res.status(400).json({error:'Invalid request',details:p.error.flatten()});
  const {to,channel,template,language,variables}=p.data;
  const c=await query('SELECT id,opted_in FROM contacts WHERE phone=$1',[to]);
  if(!c.rowCount || !c.rows[0].opted_in) return res.status(403).json({error:'Recipient has not been recorded as opted in'});
  const id=crypto.randomUUID();
  await query(`INSERT INTO messages(id,contact_id,to_number,channel,template,language,variables,status)
    VALUES($1,$2,$3,$4,$5,$6,$7,'queued')`,
    [id,c.rows[0].id,to,channel,template,language,JSON.stringify(variables)]);
  await messageQueue.add('send',{id,to,channel,template,language,variables},{
    attempts:3,backoff:{type:'exponential',delay:3000},removeOnComplete:100,removeOnFail:100
  });
  res.status(202).json({success:true,message_id:id,status:'queued'});
});

app.get('/api/v1/messages',auth,async(req,res)=>{
  const limit=Math.min(Math.max(Number(req.query.limit)||50,1),200);
  const r=await query(`SELECT id,to_number,channel,template,language,status,provider_id,error,created_at,sent_at,delivered_at,read_at
    FROM messages ORDER BY created_at DESC LIMIT $1`,[limit]);
  res.json({messages:r.rows});
});

app.get('/api/v1/stats',auth,async(_,res)=>{
  const r=await query(`SELECT status,count(*)::int AS count FROM messages GROUP BY status`);
  res.json({stats:r.rows});
});

app.get('/api/v1/templates',auth,async(_,res)=>{
  const r=await query('SELECT id,name,language,active,created_at FROM templates ORDER BY name');
  res.json({templates:r.rows});
});

app.get('/webhooks/whatsapp',(req,res)=>{
  const mode=req.query['hub.mode'],token=req.query['hub.verify_token'],challenge=req.query['hub.challenge'];
  if(mode==='subscribe' && token===process.env.WHATSAPP_VERIFY_TOKEN) return res.status(200).send(challenge);
  res.sendStatus(403);
});

app.post('/webhooks/whatsapp',async(req,res)=>{
  const raw=Buffer.isBuffer(req.body)?req.body:Buffer.from(JSON.stringify(req.body));
  const signature=req.header('X-Hub-Signature-256');
  const configured=Boolean(process.env.WHATSAPP_APP_SECRET);
  const valid=configured ? verifyMetaSignature(raw,signature,process.env.WHATSAPP_APP_SECRET) : true;
  if(configured && !valid) return res.status(401).send('Invalid signature');
  let payload;
  try { payload=JSON.parse(raw.toString('utf8')); } catch { return res.status(400).send('Invalid JSON'); }
  await query(`INSERT INTO webhook_events(provider,event_type,payload,signature_valid) VALUES($1,$2,$3,$4)`,
    ['whatsapp',payload?.entry?.[0]?.changes?.[0]?.field || 'unknown',JSON.stringify(payload),valid]);
  // Update delivery/read statuses from common Cloud API status payloads.
  for(const entry of payload.entry || []) for(const change of entry.changes || []) {
    for(const s of change.value?.statuses || []) {
      const status=s.status;
      const column=status==='delivered'?'delivered_at':status==='read'?'read_at':null;
      if(column) await query(`UPDATE messages SET status=$1,${column}=now(),updated_at=now() WHERE provider_id=$2`,[status,s.id]);
    }
  }
  res.sendStatus(200);
});

const port=Number(process.env.PORT)||4000;
app.listen(port,()=>console.log(`API listening on ${port}`));
