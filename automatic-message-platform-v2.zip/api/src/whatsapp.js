export async function sendWhatsApp({to,template,language='en_US',variables={}}) {
  const token=process.env.WHATSAPP_ACCESS_TOKEN;
  const phoneId=process.env.WHATSAPP_PHONE_NUMBER_ID;
  const version=process.env.WHATSAPP_GRAPH_VERSION || 'v23.0';
  if(!token || !phoneId) throw new Error('WhatsApp credentials are not configured');

  const parameters=Object.values(variables).map(v=>({type:'text',text:String(v)}));
  const body={
    messaging_product:'whatsapp',
    to,
    type:'template',
    template:{
      name:template,
      language:{code:language},
      ...(parameters.length ? {components:[{type:'body',parameters}]} : {})
    }
  };
  const response=await fetch(`https://graph.facebook.com/${version}/${phoneId}/messages`,{
    method:'POST',
    headers:{Authorization:`Bearer ${token}`,'Content-Type':'application/json'},
    body:JSON.stringify(body)
  });
  const data=await response.json();
  if(!response.ok) throw new Error(data?.error?.message || 'WhatsApp API request failed');
  return data;
}
