import 'dotenv/config';
import { Worker } from 'bullmq';
import { connection } from './queue.js';
import { query } from './db.js';
import { sendWhatsApp } from './whatsapp.js';

new Worker('messages', async job => {
  const {id,to,template,language,variables}=job.data;
  await query(`UPDATE messages SET status='processing',updated_at=now() WHERE id=$1`,[id]);
  try {
    const result=await sendWhatsApp({to,template,language,variables});
    const providerId=result?.messages?.[0]?.id || null;
    await query(`UPDATE messages SET status='sent',provider_id=$2,sent_at=now(),updated_at=now() WHERE id=$1`,[id,providerId]);
  } catch (e) {
    await query(`UPDATE messages SET status='failed',error=$2,updated_at=now() WHERE id=$1`,[id,String(e.message)]);
    throw e;
  }
},{connection,concurrency:5});
console.log('Message worker running');
