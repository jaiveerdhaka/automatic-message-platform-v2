export const metadata={title:'Automatic Message Dashboard'};
export default function Layout({children}){return <html><body style={{margin:0}}>{children}</body></html>}
