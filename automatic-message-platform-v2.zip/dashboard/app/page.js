'use client';
import {useEffect,useState} from 'react';
const API=process.env.NEXT_PUBLIC_API_URL||'http://localhost:4000';
export default function Home(){
 const [key,setKey]=useState(''),[rows,setRows]=useState([]),[stats,setStats]=useState([]),[loading,setLoading]=useState(false),[err,setErr]=useState('');
 async function load(){
  if(!key){setErr('Enter API key');return}
  setLoading(true);setErr('');
  try{
   const h={'X-API-Key':key};
   const [a,b]=await Promise.all([fetch(API+'/api/v1/messages',{headers:h}),fetch(API+'/api/v1/stats',{headers:h})]);
   const ad=await a.json(),bd=await b.json();
   if(!a.ok) throw new Error(ad.error||'Request failed');
   setRows(ad.messages||[]);setStats(bd.stats||[]);
  }catch(e){setErr(e.message)}
  finally{setLoading(false)}
 }
 useEffect(()=>{const saved=localStorage.getItem('api_key');if(saved){setKey(saved)}},[]);
 return <main style={{maxWidth:1200,margin:'0 auto',padding:32,fontFamily:'Arial,sans-serif'}}>
  <h1>Automatic Message Dashboard</h1>
  <p>WhatsApp message queue, delivery status and API logs.</p>
  <div style={{display:'flex',gap:8}}>
   <input type="password" value={key} onChange={e=>{setKey(e.target.value);localStorage.setItem('api_key',e.target.value)}} placeholder="X-API-Key" style={{padding:12,flex:1}}/>
   <button onClick={load} style={{padding:'12px 18px'}}>{loading?'Loading…':'Refresh'}</button>
  </div>
  {err&&<p style={{color:'crimson'}}>{err}</p>}
  <section style={{display:'flex',gap:12,flexWrap:'wrap',margin:'24px 0'}}>
   {stats.map(s=><div key={s.status} style={{border:'1px solid #ddd',borderRadius:10,padding:16,minWidth:130}}><b>{s.status}</b><div style={{fontSize:28}}>{s.count}</div></div>)}
  </section>
  <div style={{overflowX:'auto'}}>
   <table style={{width:'100%',borderCollapse:'collapse'}}>
    <thead><tr>{['ID','Recipient','Template','Status','Provider ID','Created'].map(x=><th key={x} style={{textAlign:'left',borderBottom:'2px solid #ddd',padding:10}}>{x}</th>)}</tr></thead>
    <tbody>{rows.map(x=><tr key={x.id}>{[x.id.slice(0,8),x.to_number,x.template,x.status,x.provider_id||'—',new Date(x.created_at).toLocaleString()].map((v,i)=><td key={i} style={{borderBottom:'1px solid #eee',padding:10}}>{v}</td>)}</tr>)}</tbody>
   </table>
  </div>
 </main>
}
